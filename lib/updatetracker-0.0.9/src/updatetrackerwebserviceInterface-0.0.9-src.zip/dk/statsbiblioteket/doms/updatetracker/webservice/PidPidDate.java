
package dk.statsbiblioteket.doms.updatetracker.webservice;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for pidPidDate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="pidPidDate">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="collectionPid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="entryCMPid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="beginTime" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "pidPidDate", propOrder = {
    "collectionPid",
    "entryCMPid",
    "beginTime"
})
public class PidPidDate {

    @XmlElement(required = true)
    protected java.lang.String collectionPid;
    @XmlElement(required = true)
    protected java.lang.String entryCMPid;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar beginTime;

    /**
     * Gets the value of the collectionPid property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getCollectionPid() {
        return collectionPid;
    }

    /**
     * Sets the value of the collectionPid property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setCollectionPid(java.lang.String value) {
        this.collectionPid = value;
    }

    /**
     * Gets the value of the entryCMPid property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getEntryCMPid() {
        return entryCMPid;
    }

    /**
     * Sets the value of the entryCMPid property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setEntryCMPid(java.lang.String value) {
        this.entryCMPid = value;
    }

    /**
     * Gets the value of the beginTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBeginTime() {
        return beginTime;
    }

    /**
     * Sets the value of the beginTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBeginTime(XMLGregorianCalendar value) {
        this.beginTime = value;
    }

}
