
package dk.statsbiblioteket.doms.bitstorage.highlevel;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for uploadFileToObjectFromPermanentURLWithCharacterisation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="uploadFileToObjectFromPermanentURLWithCharacterisation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="pid" type="{http://highlevel.bitstorage.doms.statsbiblioteket.dk/}fedoraPid"/>
 *         &lt;element name="filename" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="permanentURL" type="{http://www.w3.org/2001/XMLSchema}anyURI"/>
 *         &lt;element name="md5string" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="filelength" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="characterisation" type="{http://doms.statsbiblioteket.dk/types/characterisation/0/2/#}characterisation"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "uploadFileToObjectFromPermanentURLWithCharacterisation", propOrder = {
    "pid",
    "filename",
    "permanentURL",
    "md5String",
    "filelength",
    "characterisation"
})
@XmlRootElement(name = "uploadFileToObjectFromPermanentURLWithCharacterisation")
public class UploadFileToObjectFromPermanentURLWithCharacterisation {

    @XmlElement(required = true)
    protected String pid;
    @XmlElement(required = true)
    protected String filename;
    @XmlElement(required = true)
    @XmlSchemaType(name = "anyURI")
    protected String permanentURL;
    @XmlElement(name = "md5string", required = true)
    protected String md5String;
    protected long filelength;
    @XmlElement(required = true)
    protected Characterisation characterisation;

    /**
     * Gets the value of the pid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPid() {
        return pid;
    }

    /**
     * Sets the value of the pid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPid(String value) {
        this.pid = value;
    }

    /**
     * Gets the value of the filename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFilename() {
        return filename;
    }

    /**
     * Sets the value of the filename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFilename(String value) {
        this.filename = value;
    }

    /**
     * Gets the value of the permanentURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPermanentURL() {
        return permanentURL;
    }

    /**
     * Sets the value of the permanentURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPermanentURL(String value) {
        this.permanentURL = value;
    }

    /**
     * Gets the value of the md5String property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMd5String() {
        return md5String;
    }

    /**
     * Sets the value of the md5String property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMd5String(String value) {
        this.md5String = value;
    }

    /**
     * Gets the value of the filelength property.
     * 
     */
    public long getFilelength() {
        return filelength;
    }

    /**
     * Sets the value of the filelength property.
     * 
     */
    public void setFilelength(long value) {
        this.filelength = value;
    }

    /**
     * Gets the value of the characterisation property.
     * 
     * @return
     *     possible object is
     *     {@link Characterisation }
     *     
     */
    public Characterisation getCharacterisation() {
        return characterisation;
    }

    /**
     * Sets the value of the characterisation property.
     * 
     * @param value
     *     allowed object is
     *     {@link Characterisation }
     *     
     */
    public void setCharacterisation(Characterisation value) {
        this.characterisation = value;
    }

}
