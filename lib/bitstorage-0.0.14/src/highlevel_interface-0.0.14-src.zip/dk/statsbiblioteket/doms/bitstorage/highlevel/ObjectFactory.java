
package dk.statsbiblioteket.doms.bitstorage.highlevel;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the dk.statsbiblioteket.doms.bitstorage.highlevel package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CharacterisationFailedException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "CharacterisationFailedException");
    private final static QName _InvalidFilenameException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "InvalidFilenameException");
    private final static QName _FileIsLockedException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "FileIsLockedException");
    private final static QName _ObjectNotFoundException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "ObjectNotFoundException");
    private final static QName _FileAlreadyApprovedException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "FileAlreadyApprovedException");
    private final static QName _CommunicationException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "CommunicationException");
    private final static QName _FileNotFoundException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "FileNotFoundException");
    private final static QName _UploadFailedException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "UploadFailedException");
    private final static QName _ChecksumFailedException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "ChecksumFailedException");
    private final static QName _NotEnoughFreeSpaceException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "NotEnoughFreeSpaceException");
    private final static QName _FileObjectAlreadyInUseException_QNAME = new QName("http://highlevel.bitstorage.doms.statsbiblioteket.dk/", "FileObjectAlreadyInUseException");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: dk.statsbiblioteket.doms.bitstorage.highlevel
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Publish }
     * 
     */
    public Publish createPublish() {
        return new Publish();
    }

    /**
     * Create an instance of {@link UploadFileToObjectWithCharacterisation }
     * 
     */
    public UploadFileToObjectWithCharacterisation createUploadFileToObjectWithCharacterisation() {
        return new UploadFileToObjectWithCharacterisation();
    }

    /**
     * Create an instance of {@link Delete }
     * 
     */
    public Delete createDelete() {
        return new Delete();
    }

    /**
     * Create an instance of {@link UploadFileToObject }
     * 
     */
    public UploadFileToObject createUploadFileToObject() {
        return new UploadFileToObject();
    }

    /**
     * Create an instance of {@link Characterisation }
     * 
     */
    public Characterisation createCharacterisation() {
        return new Characterisation();
    }

    /**
     * Create an instance of {@link PublishResponse }
     * 
     */
    public PublishResponse createPublishResponse() {
        return new PublishResponse();
    }

    /**
     * Create an instance of {@link UploadFileToObjectFromPermanentURLWithCharacterisation }
     * 
     */
    public UploadFileToObjectFromPermanentURLWithCharacterisation createUploadFileToObjectFromPermanentURLWithCharacterisation() {
        return new UploadFileToObjectFromPermanentURLWithCharacterisation();
    }

    /**
     * Create an instance of {@link UploadFileToObjectResponse }
     * 
     */
    public UploadFileToObjectResponse createUploadFileToObjectResponse() {
        return new UploadFileToObjectResponse();
    }

    /**
     * Create an instance of {@link UploadFileToObjectFromPermanentURL }
     * 
     */
    public UploadFileToObjectFromPermanentURL createUploadFileToObjectFromPermanentURL() {
        return new UploadFileToObjectFromPermanentURL();
    }

    /**
     * Create an instance of {@link DeleteResponse }
     * 
     */
    public DeleteResponse createDeleteResponse() {
        return new DeleteResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "CharacterisationFailedException")
    public JAXBElement<String> createCharacterisationFailedException(String value) {
        return new JAXBElement<String>(_CharacterisationFailedException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "InvalidFilenameException")
    public JAXBElement<String> createInvalidFilenameException(String value) {
        return new JAXBElement<String>(_InvalidFilenameException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "FileIsLockedException")
    public JAXBElement<String> createFileIsLockedException(String value) {
        return new JAXBElement<String>(_FileIsLockedException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "ObjectNotFoundException")
    public JAXBElement<String> createObjectNotFoundException(String value) {
        return new JAXBElement<String>(_ObjectNotFoundException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "FileAlreadyApprovedException")
    public JAXBElement<String> createFileAlreadyApprovedException(String value) {
        return new JAXBElement<String>(_FileAlreadyApprovedException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "CommunicationException")
    public JAXBElement<String> createCommunicationException(String value) {
        return new JAXBElement<String>(_CommunicationException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "FileNotFoundException")
    public JAXBElement<String> createFileNotFoundException(String value) {
        return new JAXBElement<String>(_FileNotFoundException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "UploadFailedException")
    public JAXBElement<String> createUploadFailedException(String value) {
        return new JAXBElement<String>(_UploadFailedException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "ChecksumFailedException")
    public JAXBElement<String> createChecksumFailedException(String value) {
        return new JAXBElement<String>(_ChecksumFailedException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "NotEnoughFreeSpaceException")
    public JAXBElement<String> createNotEnoughFreeSpaceException(String value) {
        return new JAXBElement<String>(_NotEnoughFreeSpaceException_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://highlevel.bitstorage.doms.statsbiblioteket.dk/", name = "FileObjectAlreadyInUseException")
    public JAXBElement<String> createFileObjectAlreadyInUseException(String value) {
        return new JAXBElement<String>(_FileObjectAlreadyInUseException_QNAME, String.class, null, value);
    }

}
