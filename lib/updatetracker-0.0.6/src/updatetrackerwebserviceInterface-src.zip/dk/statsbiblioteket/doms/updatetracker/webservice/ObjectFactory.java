
package dk.statsbiblioteket.doms.updatetracker.webservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the dk.statsbiblioteket.doms.updatetracker.webservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetLatestModificationTime_QNAME = new QName("http://updatetracker.doms.statsbiblioteket.dk/", "getLatestModificationTime");
    private final static QName _GetLatestModificationTimeResponse_QNAME = new QName("http://updatetracker.doms.statsbiblioteket.dk/", "getLatestModificationTimeResponse");
    private final static QName _InvalidResourceException_QNAME = new QName("http://updatetracker.doms.statsbiblioteket.dk/", "InvalidResourceException");
    private final static QName _ListObjectsChangedSince_QNAME = new QName("http://updatetracker.doms.statsbiblioteket.dk/", "listObjectsChangedSince");
    private final static QName _MethodFailedException_QNAME = new QName("http://updatetracker.doms.statsbiblioteket.dk/", "MethodFailedException");
    private final static QName _ListObjectsChangedSinceResponse_QNAME = new QName("http://updatetracker.doms.statsbiblioteket.dk/", "listObjectsChangedSinceResponse");
    private final static QName _InvalidCredentialsException_QNAME = new QName("http://updatetracker.doms.statsbiblioteket.dk/", "InvalidCredentialsException");
    private final static QName _PidPidAngleDateStringLimit_QNAME = new QName("", "limit");
    private final static QName _PidPidAngleDateStringOffset_QNAME = new QName("", "offset");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: dk.statsbiblioteket.doms.updatetracker.webservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Long }
     * 
     */
    public Long createLong() {
        return new Long();
    }

    /**
     * Create an instance of {@link Date }
     * 
     */
    public Date createDate() {
        return new Date();
    }

    /**
     * Create an instance of {@link PidDatePidPid }
     * 
     */
    public PidDatePidPid createPidDatePidPid() {
        return new PidDatePidPid();
    }

    /**
     * Create an instance of {@link PidPidAngleDateString }
     * 
     */
    public PidPidAngleDateString createPidPidAngleDateString() {
        return new PidPidAngleDateString();
    }

    /**
     * Create an instance of {@link Pidlist }
     * 
     */
    public Pidlist createPidlist() {
        return new Pidlist();
    }

    /**
     * Create an instance of {@link dk.statsbiblioteket.doms.updatetracker.webservice.String }
     * 
     */
    public dk.statsbiblioteket.doms.updatetracker.webservice.String createString() {
        return new dk.statsbiblioteket.doms.updatetracker.webservice.String();
    }

    /**
     * Create an instance of {@link URL }
     * 
     */
    public URL createURL() {
        return new URL();
    }

    /**
     * Create an instance of {@link PidAndName }
     * 
     */
    public PidAndName createPidAndName() {
        return new PidAndName();
    }

    /**
     * Create an instance of {@link PidDatePidPidList }
     * 
     */
    public PidDatePidPidList createPidDatePidPidList() {
        return new PidDatePidPidList();
    }

    /**
     * Create an instance of {@link PidPidAngleInput }
     * 
     */
    public PidPidAngleInput createPidPidAngleInput() {
        return new PidPidAngleInput();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PidPidAngleInput }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://updatetracker.doms.statsbiblioteket.dk/", name = "getLatestModificationTime")
    public JAXBElement<PidPidAngleInput> createGetLatestModificationTime(PidPidAngleInput value) {
        return new JAXBElement<PidPidAngleInput>(_GetLatestModificationTime_QNAME, PidPidAngleInput.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://updatetracker.doms.statsbiblioteket.dk/", name = "getLatestModificationTimeResponse")
    public JAXBElement<Long> createGetLatestModificationTimeResponse(Long value) {
        return new JAXBElement<Long>(_GetLatestModificationTimeResponse_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link java.lang.String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://updatetracker.doms.statsbiblioteket.dk/", name = "InvalidResourceException")
    public JAXBElement<java.lang.String> createInvalidResourceException(java.lang.String value) {
        return new JAXBElement<java.lang.String>(_InvalidResourceException_QNAME, java.lang.String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PidPidAngleDateString }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://updatetracker.doms.statsbiblioteket.dk/", name = "listObjectsChangedSince")
    public JAXBElement<PidPidAngleDateString> createListObjectsChangedSince(PidPidAngleDateString value) {
        return new JAXBElement<PidPidAngleDateString>(_ListObjectsChangedSince_QNAME, PidPidAngleDateString.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link java.lang.String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://updatetracker.doms.statsbiblioteket.dk/", name = "MethodFailedException")
    public JAXBElement<java.lang.String> createMethodFailedException(java.lang.String value) {
        return new JAXBElement<java.lang.String>(_MethodFailedException_QNAME, java.lang.String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PidDatePidPidList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://updatetracker.doms.statsbiblioteket.dk/", name = "listObjectsChangedSinceResponse")
    public JAXBElement<PidDatePidPidList> createListObjectsChangedSinceResponse(PidDatePidPidList value) {
        return new JAXBElement<PidDatePidPidList>(_ListObjectsChangedSinceResponse_QNAME, PidDatePidPidList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link java.lang.String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://updatetracker.doms.statsbiblioteket.dk/", name = "InvalidCredentialsException")
    public JAXBElement<java.lang.String> createInvalidCredentialsException(java.lang.String value) {
        return new JAXBElement<java.lang.String>(_InvalidCredentialsException_QNAME, java.lang.String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "limit", scope = PidPidAngleDateString.class)
    public JAXBElement<Integer> createPidPidAngleDateStringLimit(Integer value) {
        return new JAXBElement<Integer>(_PidPidAngleDateStringLimit_QNAME, Integer.class, PidPidAngleDateString.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "offset", scope = PidPidAngleDateString.class)
    public JAXBElement<Integer> createPidPidAngleDateStringOffset(Integer value) {
        return new JAXBElement<Integer>(_PidPidAngleDateStringOffset_QNAME, Integer.class, PidPidAngleDateString.class, value);
    }

}
