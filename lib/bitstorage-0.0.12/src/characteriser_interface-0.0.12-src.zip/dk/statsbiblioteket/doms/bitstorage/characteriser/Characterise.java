
package dk.statsbiblioteket.doms.bitstorage.characteriser;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for characterise complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="characterise">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://characterise.bitstorage.doms.statsbiblioteket.dk/}pid"/>
 *         &lt;element ref="{http://characterise.bitstorage.doms.statsbiblioteket.dk/}acceptedFormats" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "characterise", propOrder = {
    "pid",
    "acceptedFormats"
})
@XmlRootElement(name = "characterise")
public class Characterise {

    @XmlElement(namespace = "http://characterise.bitstorage.doms.statsbiblioteket.dk/", required = true)
    protected String pid;
    @XmlElement(namespace = "http://characterise.bitstorage.doms.statsbiblioteket.dk/")
    @XmlSchemaType(name = "anyURI")
    protected List<String> acceptedFormats;

    /**
     * Gets the value of the pid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPid() {
        return pid;
    }

    /**
     * Sets the value of the pid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPid(String value) {
        this.pid = value;
    }

    /**
     * Gets the value of the acceptedFormats property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the acceptedFormats property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAcceptedFormats().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getAcceptedFormats() {
        if (acceptedFormats == null) {
            acceptedFormats = new ArrayList<String>();
        }
        return this.acceptedFormats;
    }

}
